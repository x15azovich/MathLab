require 'sinatra'
require 'sinatra/base'
require 'sinatra/flash'

class MathLabTrackerApp < Sinatra::Base
    
      register Sinatra::Flash
    
    
end