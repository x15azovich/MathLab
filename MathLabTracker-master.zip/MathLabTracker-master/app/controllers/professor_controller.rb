class ProfessorController < ApplicationController
end
