module ProfessorHelper
end
