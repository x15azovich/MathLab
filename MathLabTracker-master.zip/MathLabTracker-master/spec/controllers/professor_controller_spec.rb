require 'rails_helper'

RSpec.describe ProfessorController, type: :controller do

end
